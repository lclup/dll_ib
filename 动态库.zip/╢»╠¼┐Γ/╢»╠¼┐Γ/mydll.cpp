#include "mydll.h"


mydll::mydll(void)
{
}


mydll::~mydll(void)
{
}
int mydll:: add(int a,int b)
{
	return a+b;
}
 
int mydll:: aub(int a,int b)
{

	return a-b;
}
