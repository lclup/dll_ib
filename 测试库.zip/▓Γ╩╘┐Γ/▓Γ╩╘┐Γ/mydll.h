#pragma once
class _declspec(dllexport) mydll
{
public:
	mydll(void);
	~mydll(void);
public:
	int add(int a,int b);
	int aub(int a,int b);
};

