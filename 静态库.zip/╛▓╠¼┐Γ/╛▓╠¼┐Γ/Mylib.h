#pragma once
class Mylib
{
public:
	Mylib(void);
	~Mylib(void);
public:
	int add(int a,int b);
	int aub(int a,int b);
};

