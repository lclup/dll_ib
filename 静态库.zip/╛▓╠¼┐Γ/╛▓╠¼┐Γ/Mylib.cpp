#include "Mylib.h"


Mylib::Mylib(void)
{
}


Mylib::~Mylib(void)
{
}
int Mylib:: add(int a,int b)
{
	return a+b;
}
 
int Mylib:: aub(int a,int b)
{

	return a-b;
}